<div class="chat-body-wrap">
<div id="chat-body-errors"></div>
<p><?php echo lang("ctn_1321") ?></p>
<p class="ui-front"><input type="text" name="name" class="form-control" placeholder="Enter username(s)" id="start_chat_username"></p>
<p><input type="text" name="reply" class="form-control" id="start_chat_title" placeholder="Chat Title ..."></p>
<p><input type="text" name="reply" class="form-control" id="start_chat_message" placeholder="Your message ..."></p>
<p><input type="button" class="btn btn-default btn-sm form-control" value="Begin Chat" id="start_chat_button"></p>

</div>