<div id="chat_bar">


<div id="active_chats">

</div>

<audio id="bleep" controls>
    <source src="<?php echo base_url() ?>images/audio/Notification.wav" type="audio/mpeg">
</audio>

</div>