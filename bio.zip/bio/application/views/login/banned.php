<div class="container">
    <div class="row">
    <div class="col-md-5 center-block-e">

<div class="login-page-header">
<?php echo lang("ctn_172") ?>

</div>

<div class="login-page">
<?php echo lang("ctn_173") ?>
</div>

</div>
</div>
</div>